package com.haust.crm.service;

import com.haust.crm.entity.Sales;
import com.baomidou.mybatisplus.extension.service.IService;

public interface SalesService extends IService<Sales> {

}