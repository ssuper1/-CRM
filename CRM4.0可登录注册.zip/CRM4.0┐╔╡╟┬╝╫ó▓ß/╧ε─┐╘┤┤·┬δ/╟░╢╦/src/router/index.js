import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
	{
	  path: '/',
	  name: 'admin',   
	  component: () => import( '../components/admin.vue')
	},
  {
    path: '/customers',
    name: 'customers',   
    component: () => import( '../components/customers.vue')
  },
 {
   path: '/sale',
   name: 'sale',   
   component: () => import( '../components/sale.vue')
 },
 //3
 {
   path: '/time',
   name: 'timeManagement',   
   component: () => import( '../components/timeManagement.vue')
 },
 //4
 {
   path: '/lead',
   name: 'lead',   
   component: () => import( '../components/lead.vue')
 },
 //5
 {
   path: '/telemarketing',
   name: 'telemarketing',   
   component: () => import( '../components/telemarketing.vue')
 },
 //6
 {
   path: '/contact',
   name: 'contact',   
   component: () => import( '../components/contact.vue')
 },
 
 {
   path: '/customerService',
   name: 'customerService',   
   component: () => import( '../components/customerService.vue')
 },
 {
   path: '/partnership',
   name: 'partnership',   
   component: () => import( '../components/partnership.vue')
 },
 {
   path: '/marketing',
   name: 'marketing',   
   component: () => import( '../components/marketing.vue')
 },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
