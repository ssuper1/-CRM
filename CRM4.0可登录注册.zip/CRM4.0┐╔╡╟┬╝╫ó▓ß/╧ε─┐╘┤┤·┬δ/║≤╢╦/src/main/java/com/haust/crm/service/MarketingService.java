package com.haust.crm.service;

import com.haust.crm.entity.Marketing;
import com.baomidou.mybatisplus.extension.service.IService;

public interface MarketingService extends IService<Marketing> {

}