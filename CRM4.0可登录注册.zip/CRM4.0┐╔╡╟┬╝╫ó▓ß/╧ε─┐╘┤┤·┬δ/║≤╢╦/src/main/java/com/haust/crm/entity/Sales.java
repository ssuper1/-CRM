package com.haust.crm.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
@Data

public class Sales {
    private Integer id;           // 销售记录ID
    private Integer customerId;   // 客户ID
    private Integer productId;    // 产品ID
    private Integer quantity;     // 数量
    private Integer price;        // 价格
    @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date date;            // 日期
}