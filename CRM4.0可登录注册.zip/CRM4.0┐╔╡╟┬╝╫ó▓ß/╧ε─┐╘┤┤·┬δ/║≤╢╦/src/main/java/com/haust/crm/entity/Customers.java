package com.haust.crm.entity;

import lombok.Data;

@Data
public class Customers {
    private Integer id;
    private String name;
    private String phoneNumber;
    private String email;
    private String address;
}