package com.haust.crm.controller;

import com.haust.crm.entity.Marketing;
import com.haust.crm.service.MarketingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/marketing")
public class MarketingController {

    @Autowired
    private MarketingService marketingService;

    @GetMapping
    public List<Marketing> getAllMarketing() {
        return marketingService.list();
    }

    @GetMapping("/{id}")
    public Marketing getMarketingById(@PathVariable Integer id) {
        return marketingService.getById(id);
    }

    @PostMapping
    public void addMarketing(@RequestBody Marketing marketing) {
        marketingService.save(marketing);
    }

    @PutMapping("/{id}")
    public void updateMarketing(@PathVariable Integer id, @RequestBody Marketing marketing) {
        marketing.setId(id);
        marketingService.updateById(marketing);
    }

    @DeleteMapping("/{id}")
    public void deleteMarketing(@PathVariable Integer id) {
        marketingService.removeById(id);
    }
}