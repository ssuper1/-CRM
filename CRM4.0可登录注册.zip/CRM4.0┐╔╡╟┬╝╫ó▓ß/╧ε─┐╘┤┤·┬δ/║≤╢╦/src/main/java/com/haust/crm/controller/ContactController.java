package com.haust.crm.controller;

import com.haust.crm.entity.Contacts;
import com.haust.crm.service.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/contact")
public class ContactController {

    @Autowired
    private ContactService contactService;

    @GetMapping
    public List<Contacts> getAllContact() {
        return contactService.list();
    }

    @GetMapping("/{id}")
    public Contacts getContactById(@PathVariable Integer id) {
        return contactService.getById(id);
    }

    @PostMapping
    public void addContact(@RequestBody Contacts contacts) {
        contactService.save(contacts);
    }

    @PutMapping("/{id}")
    public void updateContact(@PathVariable Integer id, @RequestBody Contacts contacts) {
        contacts.setId(id);
        contactService.updateById(contacts);
    }

    @DeleteMapping("/{id}")
    public void deleteContact(@PathVariable Integer id) {
        contactService.removeById(id);
    }
}
