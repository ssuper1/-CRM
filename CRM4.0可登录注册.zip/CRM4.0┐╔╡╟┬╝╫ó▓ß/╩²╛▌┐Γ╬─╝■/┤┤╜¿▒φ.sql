-- 1. 客户管理
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(50),
    email VARCHAR(100),
    address TEXT
);

-- 2. 联系人管理
CREATE TABLE contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    position VARCHAR(255),
    phone_number VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- 3. 时间管理
CREATE TABLE time_management (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    contact_id INT,
    type VARCHAR(100),
    date DATE,
    duration TIME,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
);

-- 4. 潜在客户管理
CREATE TABLE lead (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(50),
    source VARCHAR(100)
);

-- 5. 销售管理
CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    quantity INT,
    price INT,
    date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE 
);

-- 6. 电话营销
CREATE TABLE telemarketing (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    contact_id INT,
    date DATE,
    duration TIME,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
);

-- 7. 营销管理
CREATE TABLE marketing (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    start_date DATE,
    end_date DATE,
    cost DECIMAL(10, 2)
);

-- 8. 客户服务
CREATE TABLE customer_service (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    type VARCHAR(100),
    date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- 9. 合作伙伴关系管理
CREATE TABLE partnership (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(50),
    address TEXT
);

CREATE TABLE admin (
    id INT PRIMARY KEY AUTO_INCREMENT,
		account VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);