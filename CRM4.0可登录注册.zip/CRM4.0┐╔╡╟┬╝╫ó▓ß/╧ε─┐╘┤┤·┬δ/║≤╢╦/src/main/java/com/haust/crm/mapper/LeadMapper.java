package com.haust.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.haust.crm.entity.Lead;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LeadMapper extends BaseMapper<Lead> {

}