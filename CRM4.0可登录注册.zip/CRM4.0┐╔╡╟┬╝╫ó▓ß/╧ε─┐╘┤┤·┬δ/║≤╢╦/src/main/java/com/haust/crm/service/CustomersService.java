package com.haust.crm.service;

import com.haust.crm.entity.Customers;
import com.baomidou.mybatisplus.extension.service.IService;

public interface CustomersService extends IService<Customers> {

}
