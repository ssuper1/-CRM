
controller
ContactController

// ContactController.java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/contacts")
public class ContactController {

    private final ContactService contactService;

    @Autowired
    public ContactController(ContactService contactService) {
        this.contactService = contactService;
    }

    @GetMapping
    public List<Contact> getAllContacts() {
        return contactService.findAll();
    }

    @GetMapping("/{id}")
    public Contact getContactById(@PathVariable Integer id) {
        return contactService.findById(id);
    }

    @PostMapping
    public void addContact(@RequestBody Contact contact) {
        contactService.insert(contact);
    }

    @PutMapping("/{id}")
    public void updateContact(@RequestBody Contact contact, @PathVariable Integer id) {
        contact.setId(id);
        contactService.update(contact);
    }

    @DeleteMapping("/{id}")
    public void deleteContact(@PathVariable Integer id) {
        contactService.delete(id);
    }
}
---------------------------------
entity
Contact

// Contact.java
public class Contact {
    private Integer id;           // 联系人ID
    private Integer customerId;   // 客户ID
    private String name;          // 姓名
    private String position;      // 职位
    private String phoneNumber;   // 联系方式

    // Constructors
    public Contact() {}

    public Contact(Integer id, Integer customerId, String name, String position, String phoneNumber) {
        this.id = id;
        this.customerId = customerId;
        this.name = name;
        this.position = position;
        this.phoneNumber = phoneNumber;
    }

    // Getters and Setters
    // ...

    // toString method for debugging
    @Override
    public String toString() {
        return "Contact{" +
                "id=" + id +
                ", customerId=" + customerId +
                ", name='" + name + '\'' +
                ", position='" + position + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }
}
---------------------------------
mapper
ContactMapper

// ContactMapper.java
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface ContactMapper {
    @Select("SELECT * FROM contacts WHERE 1=1")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "customerId", column = "customer_id"),
        @Result(property = "name", column = "name"),
        @Result(property = "position", column = "position"),
        @Result(property = "phoneNumber", column = "phone_number")
    })
    List<Contact> findAll();

    @Select("SELECT * FROM contacts WHERE id = #{id}")
    Contact findById(Integer id);

    @Insert("INSERT INTO contacts (customer_id, name, position, phone_number) VALUES (#{customerId}, #{name}, #{position}, #{phoneNumber})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(Contact contact);

    @Update("UPDATE contacts SET customer_id = #{customerId}, name = #{name}, position = #{position}, phone_number = #{phoneNumber} WHERE id = #{id}")
    void update(Contact contact);

    @Delete("DELETE FROM contacts WHERE id = #{id}")
    void delete(Integer id);
}
---------------------------------
service
ContactService

// ContactService.java
public interface ContactService {
    List<Contact> findAll();
    Contact findById(Integer id);
    void insert(Contact contact);
    void update(Contact contact);
    void delete(Integer id);
}
---------------------------------
impl
ContactServiceimpl(impl这一部分位于文件service下方)

// ContactServiceImpl.java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ContactServiceImpl implements ContactService {

    private final ContactMapper contactMapper;

    @Autowired
    public ContactServiceImpl(ContactMapper contactMapper) {
        this.contactMapper = contactMapper;
    }

    @Override
    public List<Contact> findAll() {
        return contactMapper.findAll();
    }

    @Override
    public Contact findById(Integer id) {
        return contactMapper.findById(id);
    }

    @Override
    @Transactional
    public void insert(Contact contact) {
        contactMapper.insert(contact);
    }

    @Override
    @Transactional
    public void update(Contact contact) {
        contactMapper.update(contact);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        contactMapper.delete(id);
    }
}
---------------------------------






