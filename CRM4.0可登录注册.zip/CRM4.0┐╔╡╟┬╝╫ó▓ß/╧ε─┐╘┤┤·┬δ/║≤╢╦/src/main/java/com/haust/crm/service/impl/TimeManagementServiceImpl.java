package com.haust.crm.service.impl;

import com.haust.crm.entity.TimeManagement;
import com.haust.crm.mapper.TimeManagementMapper;
import com.haust.crm.service.TimeManagementService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class TimeManagementServiceImpl extends ServiceImpl<TimeManagementMapper, TimeManagement> implements TimeManagementService {
}