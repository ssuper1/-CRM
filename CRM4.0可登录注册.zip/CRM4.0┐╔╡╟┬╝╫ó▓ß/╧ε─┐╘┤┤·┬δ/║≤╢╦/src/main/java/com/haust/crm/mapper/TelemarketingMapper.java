package com.haust.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.haust.crm.entity.Telemarketing;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TelemarketingMapper extends BaseMapper<Telemarketing> {

}