package com.haust.crm.entity;

import lombok.Data;

@Data
public class Partnership {
    private Integer id; // 主键
    private String name; // 名称
    private String phoneNumber; // 电话号码
    private String address; // 地址

    // Lombok 的 @Data 注解会为类自动生成 getter 和 setter 方法、toString 方法、equals 和 hashCode 方法
}