import axios from 'axios';

const Customers = axios.create({
  baseURL: 'http://localhost:8086/api/customers', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
const Contact = axios.create({
  baseURL: 'http://localhost:8086/api/contact', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
const CustomerService = axios.create({
  baseURL: 'http://localhost:8086/api/customerService', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
const Lead = axios.create({
  baseURL: 'http://localhost:8086/api/lead', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});

const Marketing = axios.create({
  baseURL: 'http://localhost:8086/api/marketing', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
const Partnership = axios.create({
  baseURL: 'http://localhost:8086/api/partnership', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
const Sale = axios.create({
  baseURL: 'http://localhost:8086/api/sale', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
const Telemarketing = axios.create({
  baseURL: 'http://localhost:8086/api/telemarketing', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
 const Time = axios.create({
  baseURL: 'http://localhost:8086/api/time', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
}); 
export { Customers,Contact,CustomerService,Lead,Marketing
,Partnership,Telemarketing,Sale,Time};