package com.haust.crm.service;

import com.haust.crm.entity.Contacts;
import com.baomidou.mybatisplus.extension.service.IService;

public interface ContactService extends IService<Contacts> {

}