<template>
	<el-menu
	:default-active="activeIndex" 
	class="el-menu-demo" 
	mode="horizontal" 
	@select="handleSelect">
	  <el-menu-item index="/" >客户管理</el-menu-item>
	  <el-menu-item index="/contact">联系人</el-menu-item>
	  <el-menu-item index="/time">时间管理</el-menu-item>
	  <el-menu-item index="/lead">潜在客户</el-menu-item>
	  <el-menu-item index="/sale">销售情况</el-menu-item>
	  <el-menu-item index="/telemarketing">电话营销</el-menu-item>
	   <el-menu-item index="/marketing">营销管理</el-menu-item>
	   <el-menu-item index="/customerService" >客户服务</el-menu-item>
	<el-menu-item index="/partnership" >合作伙伴</el-menu-item>
	   
	   
	</el-menu>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { ElMenu, ElMenuItem } from 'element-plus';
import { useRouter, useRoute } from 'vue-router';

const router = useRouter();//功能项
const route = useRoute();//实体项
const activeIndex = ref(route.path); // 根据当前路由设置初始激活项

const handleSelect = (index) => {
  router.push(index);
  activeIndex.value = index; // 点击菜单项时更新激活项
};
</script>
<style>
	.el-menu-demo{
		background-color: #e0f1ff; /* 根据需要调整背景色 */
	}
</style>