<template>
	<NavBar/>
  <div>
	  <div class="top">
	  		  <div class="left">
	  		<!-- 添加按钮 -->
	  			<el-button type="success" @click="showAddDialog = true">增加信息</el-button>
	  		  </div>
	  		<!-- 搜索框 -->
	  		<div class="search-box">
	  			  <el-input
	  				v-model="searchParams.queryString"
	  				placeholder="输入ID或姓名"
	  				class="search-input"
	  			  ></el-input>
	  			<el-button type="success" @click="performSearch">查询</el-button>
	  		</div>
	   </div>
    <!-- 表格 -->
    <el-table :data="items" style="width: 100%">
      <el-table-column prop="id" label="ID" width="80"></el-table-column>
      <el-table-column prop="customerId" label="客户ID"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="position" label="职位"></el-table-column>
      <el-table-column prop="phoneNumber" label="联系方式"></el-table-column>
      <el-table-column label="操作" width="200">

        <template #default="{ row }">
          <el-button type="primary" size="small" @click="editItem(row)">修改</el-button>
          <el-button type="danger" size="small" @click="deleteItem(row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 弹窗：增加/编辑信息 -->
    <el-dialog v-model="showAddDialog" title="信息" width="40%">
      <el-form :model="itemForm"  >
        <el-form-item label="客户ID" prop="customerId">
          <el-input v-model="itemForm.customerId"></el-input>
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input v-model="itemForm.name"></el-input>
        </el-form-item>
        <el-form-item label="职位" prop="position">
          <el-input v-model="itemForm.position"></el-input>
        </el-form-item>
        <el-form-item label="联系方式" prop="phoneNumber">
          <el-input type="textarea" v-model="itemForm.phoneNumber"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="showAddDialog = false">取消</el-button>
          <el-button type="primary" @click="submitForm">提交</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
  
  <!-- “重置”按钮，仅在 canReset 为 true 时显示 -->
      <el-button
        type="warning"
        v-if="canReset"
        @click="resetSearch"
        style="margin-left: 10px;">
        重置
      </el-button>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { ElButton, ElInput, ElTable, ElTableColumn, ElDialog, ElForm, ElFormItem, ElMessage } from 'element-plus';
import { Contact } from '../api';
import NavBar from './NavBar.vue'
// 响应式变量
const showAddDialog = ref(false);
const itemForm = ref({
 id: null,
 customer_id: null, // 客户ID，根据建表语句添加 
name: '', // 姓名 
position: '', // 职位 
phone_number: '' // 联系方式 
})
;const items = ref([]);
const searchParams = ref({ queryString: '' });
const editDialogVisible = ref(false);
const currentItem = ref({});
   const canReset = ref(false);
const orishelves = ref([]);

// 组件挂载后执行
onMounted(async () => {
  // 初始化加载数据
  try {
    const response = await Contact.get('/');
    items.value = response.data;
	orishelves.value = response.data;
  } catch (error) {
    console.error('Error fetching items:', error);
  }
});

// 提交表单
const submitForm = async () => {
  try {
    const formData = itemForm.value;
    if (formData.id) {
      // 更新数据
      await Contact.put(`/${formData.id}`, formData);
    } else {
      // 添加数据
      await Contact.post('/', formData);
    }
    ElMessage.success('操作成功！');
    showAddDialog.value = false;
    itemForm.value = { id: null,  customerId: '', name: '', position: '',  phoneNumber: '' };
    // 刷新表格数据
    await fetchData();
  } catch (error) {
    console.error('Error submitting form:', error);
    ElMessage.error('操作失败，请重试！');
  }
};

// 编辑数据
const editItem = (item) => {
  itemForm.value = { ...item };
  showAddDialog.value = true;
};

// 更新数据
const updateItem = async () => {
  try {
    await Contact.put(`/${currentItem.value.id}`, currentItem.value);
    ElMessage.success('更新成功！');
    editDialogVisible.value = false;
    // 刷新表格数据
    await fetchData();
  } catch (error) {
    console.error('Error updating item:', error);
    ElMessage.error('更新失败，请重试！');
  }
};

// 删除数据
const deleteItem = async (id) => {
  try {
    await Contact.delete(`/${id}`);
    ElMessage.success('删除成功！');
    // 刷新表格数据
    await fetchData();
  } catch (error) {
    console.error('Error deleting item:', error);
    ElMessage.error('删除失败，请重试！');
  }
};

// 搜索数据
const performSearch = async () => {
  // 检查查询字符串是否为空
  	 if (searchParams.value.queryString.trim() === '') {
  	   ElMessage.error('请输入数据');
  	   return;
  	 }
  	 // 标记可以重置，因为用户已经输入了查询字符串
  	 canReset.value = true; 
  	 
     // 检查查询字符串是否为纯数字
     const queryId = String(searchParams.value.queryString).replace(/\D/g, '');
     const isNumeric = queryId !== '' ;
   
     if (isNumeric) {
       // 如果查询字符串是纯数字，则执行精准查询
       items.value = orishelves.value.filter(shelf => {
         const shelfId = shelf.id.toString();
         return shelfId === queryId;
       });
     } else {
       // 如果查询字符串包含非数字字符，则执行名称的包含查询
       items.value = orishelves.value.filter(shelf => {
         return shelf.name.toLowerCase().includes(searchParams.value.queryString.toLowerCase());
       });
     }
   };
  
  // 重置搜索条件的方法
  const resetSearch = async () => {	
  	// 重新加载货架数据以刷新显示
  	 await fetchData();
	 canReset.value = false; 
   };


// 刷新表格数据
const fetchData = async () => {
  try {
    const response = await Contact.get('/');
    items.value = response.data;
  } catch (error) {
    console.error('Error fetching items:', error);
  }
};
</script>

<style scoped>
@import 'all.css'

</style>