package com.haust.crm.entity;
import java.sql.Time;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
@Data

public class TimeManagement {
    private Integer id; // 主键
    private Integer customerId; // 客户ID
    private Integer contactId; // 联系人ID
    private String type; // 类型
    @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date date; // 日期
    @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="HH:mm:ss",timezone="GMT+8")
    private Date duration; // 持续时间
}
