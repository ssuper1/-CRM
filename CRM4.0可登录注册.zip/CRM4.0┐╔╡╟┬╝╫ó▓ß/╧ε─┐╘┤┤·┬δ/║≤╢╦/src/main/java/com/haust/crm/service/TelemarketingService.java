package com.haust.crm.service;

import com.haust.crm.entity.Telemarketing;
import com.baomidou.mybatisplus.extension.service.IService;

public interface TelemarketingService extends IService<Telemarketing> {

}