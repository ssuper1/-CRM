package com.haust.crm.service.impl;

import com.haust.crm.entity.Telemarketing;
import com.haust.crm.mapper.TelemarketingMapper;
import com.haust.crm.service.TelemarketingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class TelemarketingServiceImpl extends ServiceImpl<TelemarketingMapper, Telemarketing> implements TelemarketingService {
}