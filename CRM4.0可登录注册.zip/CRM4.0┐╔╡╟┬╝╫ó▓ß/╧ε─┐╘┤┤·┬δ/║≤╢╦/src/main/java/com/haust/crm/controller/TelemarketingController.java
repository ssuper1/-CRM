package com.haust.crm.controller;

import com.haust.crm.entity.Telemarketing;
import com.haust.crm.service.TelemarketingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/telemarketing")
public class TelemarketingController {

    @Autowired
    private TelemarketingService telemarketingService;

    @GetMapping
    public List<Telemarketing> getAllTelemarketing() {
        return telemarketingService.list();
    }

    @GetMapping("/{id}")
    public Telemarketing getTelemarketingById(@PathVariable Integer id) {
        return telemarketingService.getById(id);
    }

    @PostMapping
    public void addTelemarketing(@RequestBody Telemarketing telemarketing) {
        telemarketingService.save(telemarketing);
    }

    @PutMapping("/{id}")
    public void updateTelemarketing(@PathVariable Integer id, @RequestBody Telemarketing telemarketing) {
        telemarketing.setId(id);
        telemarketingService.updateById(telemarketing);
    }

    @DeleteMapping("/{id}")
    public void deleteTelemarketing(@PathVariable Integer id) {
        telemarketingService.removeById(id);
    }
}
