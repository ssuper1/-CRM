package com.haust.crm.service.impl;

import com.haust.crm.entity.Partnership;
import com.haust.crm.mapper.PartnershipMapper;
import com.haust.crm.service.PartnershipService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class PartnershipServiceImpl extends ServiceImpl<PartnershipMapper, Partnership> implements PartnershipService {
}