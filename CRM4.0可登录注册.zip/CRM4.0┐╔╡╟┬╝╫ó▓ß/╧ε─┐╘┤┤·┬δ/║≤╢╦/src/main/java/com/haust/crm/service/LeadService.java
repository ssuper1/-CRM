package com.haust.crm.service;

import com.haust.crm.entity.Lead;
import com.baomidou.mybatisplus.extension.service.IService;

public interface LeadService extends IService<Lead> {

}