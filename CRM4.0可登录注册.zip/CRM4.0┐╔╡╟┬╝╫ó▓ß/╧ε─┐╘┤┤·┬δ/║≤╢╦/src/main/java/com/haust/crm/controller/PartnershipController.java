package com.haust.crm.controller;

import com.haust.crm.entity.Partnership;
import com.haust.crm.service.PartnershipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/partnership")
public class PartnershipController {

    @Autowired
    private PartnershipService partnershipService;

    @GetMapping
    public List<Partnership> getAllPartnership() {
        return partnershipService.list();
    }

    @GetMapping("/{id}")
    public Partnership getPartnershipById(@PathVariable Integer id) {
        return partnershipService.getById(id);
    }

    @PostMapping
    public void addPartnership(@RequestBody Partnership partnership) {
        partnershipService.save(partnership);
    }

    @PutMapping("/{id}")
    public void updatePartnership(@PathVariable Integer id, @RequestBody Partnership partnership) {
        partnership.setId(id);
        partnershipService.updateById(partnership);
    }

    @DeleteMapping("/{id}")
    public void deletePartnership(@PathVariable Integer id) {
        partnershipService.removeById(id);
    }
}
