package com.haust.crm.service;

import com.haust.crm.entity.TimeManagement;
import com.baomidou.mybatisplus.extension.service.IService;

public interface TimeManagementService extends IService<TimeManagement> {

}