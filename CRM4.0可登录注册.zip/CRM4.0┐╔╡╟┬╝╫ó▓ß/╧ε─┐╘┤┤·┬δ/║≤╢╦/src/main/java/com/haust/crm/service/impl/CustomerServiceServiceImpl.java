package com.haust.crm.service.impl;

import com.haust.crm.entity.CustomerService;
import com.haust.crm.mapper.CustomerServiceMapper;
import com.haust.crm.service.CustomerServiceService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceServiceImpl extends ServiceImpl<CustomerServiceMapper, CustomerService> implements CustomerServiceService {
}