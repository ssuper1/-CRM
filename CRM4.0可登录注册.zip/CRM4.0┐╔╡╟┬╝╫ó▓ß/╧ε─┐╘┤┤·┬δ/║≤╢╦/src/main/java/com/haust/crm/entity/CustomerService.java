package com.haust.crm.entity;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import java.util.Date;

@Data
public class CustomerService {
    private Integer id; // 主键
    private Integer customerId; // 客户ID
    private String type; // 服务类型
    @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date date; // 服务日期

    // Lombok 的 @Data 注解会为类自动生成 getter 和 setter 方法、toString 方法、equals 和 hashCode 方法
}
