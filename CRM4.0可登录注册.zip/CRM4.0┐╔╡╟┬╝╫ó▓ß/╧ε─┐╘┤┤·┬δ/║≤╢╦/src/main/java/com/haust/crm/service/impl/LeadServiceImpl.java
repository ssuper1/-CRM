package com.haust.crm.service.impl;

import com.haust.crm.entity.Lead;
import com.haust.crm.mapper.LeadMapper;
import com.haust.crm.service.LeadService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class LeadServiceImpl extends ServiceImpl<LeadMapper, Lead> implements LeadService {
}