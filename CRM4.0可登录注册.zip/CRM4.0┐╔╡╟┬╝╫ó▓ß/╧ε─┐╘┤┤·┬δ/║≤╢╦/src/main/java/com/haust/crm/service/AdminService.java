package com.haust.crm.service;

import com.haust.crm.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

public interface AdminService extends IService<Admin> {
    Admin login(String account, String password);
}