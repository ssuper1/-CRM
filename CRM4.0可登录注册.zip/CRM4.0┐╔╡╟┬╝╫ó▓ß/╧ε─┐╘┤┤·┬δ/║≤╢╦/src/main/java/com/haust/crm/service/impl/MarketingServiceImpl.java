package com.haust.crm.service.impl;

import com.haust.crm.entity.Marketing;
import com.haust.crm.mapper.MarketingMapper;
import com.haust.crm.service.MarketingService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class MarketingServiceImpl extends ServiceImpl<MarketingMapper, Marketing> implements MarketingService {
}