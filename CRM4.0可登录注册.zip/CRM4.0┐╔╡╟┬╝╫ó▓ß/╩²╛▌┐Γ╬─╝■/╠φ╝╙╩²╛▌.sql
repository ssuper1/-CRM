-- 1. 客户管理测试数据
INSERT INTO customers (name, phone_number, email, address) VALUES
('张三', '12345678901', 'zhangsan@example.com', '北京市朝阳区'),
('李四', '23456789012', 'lisi@example.com', '上海市浦东新区');

-- 2. 联系人管理测试数据
INSERT INTO contacts (customer_id, name, position, phone_number) VALUES
(1, '王五', '销售经理', '876543210'),
(2, '赵六', '市场主管', '765432109');

-- 3. 时间管理测试数据
INSERT INTO time_management (customer_id, contact_id, type, date, duration) VALUES
(1, 1, '会议', '2024-06-24', '01:30:00'),
(2, 2, '电话', '2024-06-25', '00:30:00');

-- 4. 潜在客户管理测试数据
INSERT INTO lead (name, phone_number, source) VALUES
('潜在客户A', '11112222333', '网络'),
('潜在客户B', '444455555556', '推荐');

-- 5. 销售管理测试数据
-- 假设 product_id 为 1 的产品已存在
INSERT INTO sales (customer_id, product_id, quantity, price, date) VALUES
(1, 1, 10, 100, '2024-06-26');

-- 6. 电话营销测试数据
INSERT INTO telemarketing (customer_id, contact_id, date, duration) VALUES
(1, 1, '2024-06-27', '00:45:00');

-- 7. 营销管理测试数据
INSERT INTO marketing (name, start_date, end_date, cost) VALUES
('夏季促销', '2024-07-01', '2024-07-31', 5000.00);

-- 8. 客户服务测试数据
INSERT INTO customer_service (customer_id, type, date) VALUES
(1, '技术支持', '2024-06-28'),
(2, '咨询', '2024-06-29');

-- 9. 合作伙伴关系管理测试数据
INSERT INTO partnership (name, phone_number, address) VALUES
('合作伙伴A', '987654321', '广州市天河区'),
('合作伙伴B', '555666777', '深圳市南山区');
-- 10. 账号
INSERT INTO admin (account,password) VALUES ('1001','123'),('1002','123');