package com.haust.crm.entity;
import lombok.Data;

@Data
public class Contacts {
    private Integer id;           // 联系人ID
    private Integer customerId;   // 客户ID
    private String name;          // 姓名
    private String position;      // 职位
    private String phoneNumber;   // 联系方式
}
