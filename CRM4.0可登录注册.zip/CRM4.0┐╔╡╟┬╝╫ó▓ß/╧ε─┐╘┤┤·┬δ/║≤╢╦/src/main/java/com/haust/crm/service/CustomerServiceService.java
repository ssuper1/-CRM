package com.haust.crm.service;

import com.haust.crm.entity.CustomerService;
import com.baomidou.mybatisplus.extension.service.IService;

public interface CustomerServiceService extends IService<CustomerService> {

}