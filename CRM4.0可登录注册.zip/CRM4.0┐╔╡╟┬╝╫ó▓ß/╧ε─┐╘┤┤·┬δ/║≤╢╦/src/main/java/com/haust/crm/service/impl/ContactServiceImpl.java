package com.haust.crm.service.impl;

import com.haust.crm.entity.Contacts;
import com.haust.crm.mapper.ContactMapper;
import com.haust.crm.service.ContactService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class ContactServiceImpl extends ServiceImpl<ContactMapper, Contacts> implements ContactService {
}