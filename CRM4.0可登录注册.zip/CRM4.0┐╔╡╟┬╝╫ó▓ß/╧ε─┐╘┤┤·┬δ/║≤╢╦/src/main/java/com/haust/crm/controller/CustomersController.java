package com.haust.crm.controller;

import com.haust.crm.entity.Customers;
import com.haust.crm.service.CustomersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/customers")
public class CustomersController {

    @Autowired
    private CustomersService customersService;

    @GetMapping
    public List<Customers> getAllCustomers() {
        return customersService.list();
    }

    @GetMapping("/{id}")
    public Customers getCustomersById(@PathVariable Integer id) {
        return customersService.getById(id);
    }

    @PostMapping
    public void addCustomers(@RequestBody Customers customers) {
        customersService.save(customers);
    }

    @PutMapping("/{id}")
    public void updateCustomers(@PathVariable Integer id, @RequestBody Customers customers) {
        customers.setId(id);
        customersService.updateById(customers);
    }

    @DeleteMapping("/{id}")
    public void deleteCustomers(@PathVariable Integer id) {
        customersService.removeById(id);
    }
}