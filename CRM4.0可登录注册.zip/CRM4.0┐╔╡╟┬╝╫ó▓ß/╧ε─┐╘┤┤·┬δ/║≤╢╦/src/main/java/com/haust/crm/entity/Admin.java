package com.haust.crm.entity;


import lombok.Data;

@Data
public class Admin {
    private Integer id;
    /*将基本数据类型int包装成对象。Integer类提供了一系列的方法来操作整数，比如compareTo()、toString()等。*/
    private String account;
    private String password;
    /*lombok省去
    // Getter for id
    public Integer getId() {
        return id;
    }
    // Setter for id
    public void setId(Integer id) {
        this.id = id;
    }
    .......
    */

}
