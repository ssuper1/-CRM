package com.haust.crm.controller;

import com.haust.crm.entity.CustomerService;
import com.haust.crm.service.CustomerServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/customerService")
public class CustomerServiceController {

    @Autowired
    private CustomerServiceService customerServiceService;

    @GetMapping
    public List<CustomerService> getAllCustomerService() {
        return customerServiceService.list();
    }

    @GetMapping("/{id}")
    public CustomerService getCustomerServiceById(@PathVariable Integer id) {
        return customerServiceService.getById(id);
    }

    @PostMapping
    public void addCustomerService(@RequestBody CustomerService customerService) {
        customerServiceService.save(customerService);
    }

    @PutMapping("/{id}")
    public void updateCustomerService(@PathVariable Integer id, @RequestBody CustomerService customerService) {
        customerService.setId(id);
        customerServiceService.updateById(customerService);
    }

    @DeleteMapping("/{id}")
    public void deleteCustomerService(@PathVariable Integer id) {
        customerServiceService.removeById(id);
    }
}
