package com.haust.crm.entity;

import lombok.Data;

@Data
public class Lead  {
    private Integer id;           // 线索ID
    private String name;          // 名称
    private String phoneNumber;   // 电话号码
    private String source;        // 来源
}