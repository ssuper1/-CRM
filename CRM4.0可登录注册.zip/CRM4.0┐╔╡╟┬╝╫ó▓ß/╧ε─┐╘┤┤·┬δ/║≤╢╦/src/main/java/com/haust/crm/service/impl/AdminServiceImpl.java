package com.haust.crm.service.impl;

import com.haust.crm.entity.Admin;
import com.haust.crm.mapper.AdminMapper;
import com.haust.crm.service.AdminService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin> implements AdminService {

    @Autowired      //注入
    private AdminMapper adminMapper;

    @Override
    //表示这个方法是重写了父类中的方法

    public Admin login(String account, String password) {
        // 使用手机号查询用户信息
        Admin admin = adminMapper.selectOne(new QueryWrapper <Admin>().eq("account", account));

/*这行代码调用adminMapper的selectOne方法，传入构建好的查询条件，并存储返回的对象到admin变量中

selectOne: 这是adminMapper接口中的一个方法，用于执行查询并返回一个结果。

new：创建了QueryWrapper类的一个新实例，这里采用了匿名对象实例化，只在这里使用，没有QueryWrapper<Admin> queryWrapper = new QueryWrapper<>();

QueryWrapper：它是一个用于构建 SQL 查询条件的类。QueryWrapper 允许你以编程方式构建复杂的查询条件，包括等于（eq）、不等于（ne）、大于（gt）、小于（lt）、模糊查询（like）等。

<Admin>；指定了QueryWrapper将操作的数据类型是Admin。这意味着QueryWrapper将为Admin实体类生成相应的查询条件。

eq("account", account): 它在QueryWrapper实例上添加了一个查询条件，指定了要查询的account字段等于提供的account变量的值。

*/

        // 直接比较数据库中的密码和用户输入的原始密码
        if (admin != null && password.equals(admin.getPassword())) {
            // 账号密码匹配，返回用户信息
            return admin;
        }
        // 账号不存在或密码不匹配，返回null
        return null;
    }
}