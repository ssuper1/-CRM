package com.haust.crm.service;

import com.haust.crm.entity.Partnership;
import com.baomidou.mybatisplus.extension.service.IService;

public interface PartnershipService extends IService<Partnership> {

}