package com.haust.crm.service.impl;

import com.haust.crm.entity.Sales;
import com.haust.crm.mapper.SalesMapper;
import com.haust.crm.service.SalesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class SalesServiceImpl extends ServiceImpl<SalesMapper, Sales> implements SalesService {
}