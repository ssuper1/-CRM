import { createApp } from 'vue';
import App from './App.vue';
import router from './router'/*用于应用程序的路由管理，控制页面的导航*/
import ElementPlus from 'element-plus';// 引入Element Plus
import 'element-plus/dist/index.css';

import apiClient from './api.js';// 引入axios实例

const app = createApp(App);
app.use(router);//注册Vue Router的router到Vue应用中，使应用可以使用Vue Router提供的路由功能
app.use(ElementPlus);// 全局注册Element Plus
// 例如，将apiClient作为全局属性，这样所有组件都可以通过this.$api访问apiClient
app.config.globalProperties.$api = apiClient;

app.mount('#app');