package com.haust.crm.controller;

import com.haust.crm.entity.Sales;
import com.haust.crm.service.SalesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/sale")
public class SalesController {

    @Autowired
    private SalesService saleService;

    @GetMapping
    public List<Sales> getAllSales() {
        return saleService.list();
    }

    @GetMapping("/{id}")
    public Sales getSalesById(@PathVariable Integer id) {
        return saleService.getById(id);
    }

    @PostMapping
    public void addSales(@RequestBody Sales sale) {
        saleService.save(sale);
    }

    @PutMapping("/{id}")
    public void updateSales(@PathVariable Integer id, @RequestBody Sales sale) {
        sale.setId(id);
        saleService.updateById(sale);
    }

    @DeleteMapping("/{id}")
    public void deleteSales(@PathVariable Integer id) {
        saleService.removeById(id);
    }
}
