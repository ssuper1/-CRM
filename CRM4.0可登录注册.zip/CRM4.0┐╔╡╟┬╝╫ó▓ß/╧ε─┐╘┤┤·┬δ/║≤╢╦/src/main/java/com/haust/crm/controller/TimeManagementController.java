package com.haust.crm.controller;

import com.haust.crm.entity.TimeManagement;
import com.haust.crm.service.TimeManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/time")
public class TimeManagementController {

    @Autowired
    private TimeManagementService timeService;

    @GetMapping
    public List<TimeManagement> getAllTimeManagement() {
        return timeService.list();
    }

    @GetMapping("/{id}")
    public TimeManagement getTimeManagementById(@PathVariable Integer id) {
        return timeService.getById(id);
    }

    @PostMapping
    public void addTimeManagement(@RequestBody TimeManagement time) {
        timeService.save(time);
    }

    @PutMapping("/{id}")
    public void updateTimeManagement(@PathVariable Integer id, @RequestBody TimeManagement time) {
        time.setId(id);
        timeService.updateById(time);
    }

    @DeleteMapping("/{id}")
    public void deleteTimeManagement(@PathVariable Integer id) {
        timeService.removeById(id);
    }
}
