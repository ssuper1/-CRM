package com.haust.crm.controller;

import com.haust.crm.entity.Lead;
import com.haust.crm.service.LeadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/lead")
public class LeadController {

   @Autowired
    private LeadService leadService;

    @GetMapping
    public List<Lead> getAllLead() {
        return leadService.list();
    }

    @GetMapping("/{id}")
    public Lead getLeadById(@PathVariable Integer id) {
        return leadService.getById(id);
    }

    @PostMapping
    public void addLead(@RequestBody Lead lead) {
        leadService.save(lead);
    }

    @PutMapping("/{id}")
    public void updateLead(@PathVariable Integer id, @RequestBody Lead lead) {
        lead.setId(id);
        leadService.updateById(lead);
    }

    @DeleteMapping("/{id}")
    public void deleteLead(@PathVariable Integer id) {
        leadService.removeById(id);
    }
}