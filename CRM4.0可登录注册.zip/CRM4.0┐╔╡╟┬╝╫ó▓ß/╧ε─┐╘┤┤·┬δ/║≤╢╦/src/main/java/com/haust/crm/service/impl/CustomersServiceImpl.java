package com.haust.crm.service.impl;

import com.haust.crm.entity.Customers;
import com.haust.crm.mapper.CustomersMapper;
import com.haust.crm.service.CustomersService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class CustomersServiceImpl extends ServiceImpl<CustomersMapper, Customers> implements CustomersService {
}