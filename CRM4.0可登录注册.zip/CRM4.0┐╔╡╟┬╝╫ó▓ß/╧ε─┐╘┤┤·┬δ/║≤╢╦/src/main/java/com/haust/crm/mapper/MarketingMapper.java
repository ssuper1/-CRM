package com.haust.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.haust.crm.entity.Marketing;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MarketingMapper extends BaseMapper<Marketing> {

}